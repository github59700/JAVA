import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.UpdateOptions;
import org.bson.Document;

public class API {
    private final MongoCollection<Document> userCollection;

    public API() {
        // Initialisation de la connexion à MongoDB et récupération de la collection
        MongoDBManager dbManager = new MongoDBManager();
        MongoDatabase database = dbManager.getDatabase();
        this.userCollection = database.getCollection("users");
        
    }

    public void updateOrCreateUser(String name, boolean Optin) throws Exception {
        try {
            Document user = userCollection.find(Filters.eq("name", name)).first();
            String email = name + "@gmail.com" ;
            if (user != null) {
                // Le client existe déjà, nous mettons à jour l'opt-in
                userCollection.updateOne(Filters.eq("name", name), new Document("$set", new Document("Optin", Optin)));
                System.out.println("Client mis à jour : " + name);
            } else {
                // Le client n'existe pas, nous le créons et lui rajoutons un fake email car la colonne ne peut être doublé
                Document newUser = new Document("name", name)
                                        .append("Optin", Optin)
                                        .append("email", email);
                userCollection.insertOne(newUser);
                System.out.println("Nouveau client créé : " + name);
            }
        } catch (Exception e) {
            throw new Exception("Erreur lors de la mise à jour ou de la création du client : " + e.getMessage());
        }
    }
}
