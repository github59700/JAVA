/*import static com.mongodb.client.model.Filters.eq;

import org.bson.Document;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class test {
    public static void main( String[] args ) {

    	
        String uri = "mongodb+srv://benjaminpoinsot:MongoDB2024@cluster0.5pdl9cf.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";

        try (MongoClient mongoClient = MongoClients.create(uri)) {
            MongoDatabase database = mongoClient.getDatabase("sample_mflix");
            MongoCollection<Document> collection = database.getCollection("users");

             Document doc = collection.find(eq("name", "Benji")).first();
            if (doc != null) {
                System.out.println(doc.toJson());
            } else {
                System.out.println("No matching documents found."); 
                
      
            }
            
            Document query = new Document();
            query.put("name", "Shubham");

            Document newDocument = new Document();
            newDocument.put("name", "John");

            Document updateObject = new Document();
            updateObject.put("$set", newDocument);

            collection.updateOne(query, updateObject);
            
            Document document = new Document();
            document.put("name", "Benji");
            document.put("Optin", "0");
            collection.insertOne(document);
            
            String name = "Benji";
        	int Optin = '1';
        	updateOrCreateClient(name,Optin);
        }
    }
}*/
