public class Main {
    public static void main(String[] args) {
        try {
            API api = new API();
            // Appel de la méthode pour mettre à jour ou créer un utilisateur
            api.updateOrCreateUser("Javier", true);
        } catch (Exception e) {
            System.err.println("Une erreur est survenue : " + e.getMessage());
        }
    }
}
