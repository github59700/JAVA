/*public class User {
    private String id;
    private String username;
    private String email;
    // Getters and setters
}

import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.model.Filters;
import org.bson.Document;

import java.util.ArrayList;
import java.util.List;

public class API {
    private MongoCollection<Document> userCollection;

    public API() {
        MongoDBManager dbManager = new MongoDBManager();
        userCollection = dbManager.getDatabase().getCollection("users");
    }

    public void createUser(User user) {
        Document newUser = new Document("username", user.getUsername())
                                .append("email", user.getEmail());
        userCollection.insertOne(newUser);
    }

    public List<User> getAllUsers() {
        List<User> users = new ArrayList<>();
        MongoCursor<Document> cursor = userCollection.find().iterator();
        try {
            while (cursor.hasNext()) {
                Document doc = cursor.next();
                users.add(new User(doc.getString("username"), doc.getString("email")));
            }
        } finally {
            cursor.close();
        }
        return users;
    }

    public User getUserByUsername(String username) {
        Document userDoc = userCollection.find(Filters.eq("username", username)).first();
        if (userDoc != null) {
            return new User(userDoc.getString("username"), userDoc.getString("email"));
        }
        return null;
    }
}


import static com.mongodb.client.model.Filters.eq;

import org.bson.Document;

import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class Main {
    public static void main( String[] args ) {

    	
        String uri = "mongodb+srv://benjaminpoinsot:MongoDB2024@cluster0.5pdl9cf.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";

        try (MongoClient mongoClient = MongoClients.create(uri)) {
            MongoDatabase database = mongoClient.getDatabase("sample_mflix");
            MongoCollection<Document> collection = database.getCollection("users");

            Document doc = collection.find(eq("name", "Benji")).first();
            if (doc != null) {
                System.out.println(doc.toJson());
            } else {
                System.out.println("No matching documents found."); 
                
      
            }
            
            Document query = new Document();
            query.put("name", "Shubham");

            Document newDocument = new Document();
            newDocument.put("name", "John");

            Document updateObject = new Document();
            updateObject.put("$set", newDocument);

            collection.updateOne(query, updateObject);
            
            Document document = new Document();
            document.put("name", "Benji");
            document.put("Optin", "0");
            collection.insertOne(document);
            
            String name = "Benji";
        	int Optin = '1';
        	updateOrCreateClient(name,Optin);
        }
    }
}*/
