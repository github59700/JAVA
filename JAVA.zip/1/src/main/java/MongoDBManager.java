import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;

public class MongoDBManager {
    private static final String DATABASE_NAME = "sample_mflix";
    private final MongoClient mongoClient;
    private final MongoDatabase database;

    public MongoDBManager() {
    	String uri = "mongodb+srv://benjaminpoinsot:MongoDB2024@cluster0.5pdl9cf.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0";
        this.mongoClient = MongoClients.create(uri);
        this.database = mongoClient.getDatabase(DATABASE_NAME);
    }

    public MongoDatabase getDatabase() {
        return database;
    }
}
