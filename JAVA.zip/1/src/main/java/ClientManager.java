/*import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.UpdateOptions;
import org.bson.Document;

public class ClientManager {
    private final MongoCollection<Document> clientCollection;

    public ClientManager(MongoDatabase database) {
        this.clientCollection = database.getCollection("clients");
    }

    public void updateOrCreateClient(String name, int Optin) {
        Document client = clientCollection.find(Filters.eq("name", name)).first();
        if (client != null) {
            // Le client existe déjà, mettre à jour l'opt-in
            clientCollection.updateOne(Filters.eq("name", name), new Document("$set", new Document("Optin", Optin)));
            System.out.println("Client mis à jour : " + name);
        } else {
            // Le client n'existe pas, le créer
            Document newClient = new Document("name", name)
                                        .append("Optin", Optin);
            clientCollection.insertOne(newClient);
            System.out.println("Nouveau client créé : " + name);
        }
    }
}*/
